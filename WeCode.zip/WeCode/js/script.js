function openNav(){
	document.getElementById("Nav").style.width= '30%';
}

function closeNav(){
	document.getElementById("Nav").style.width= '0%';
}

const imgs = document.getElementById("img");
const img = document.getElementById("#img img");

let idx = 0;

var swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });

var swiper = new Swiper(".slide-container", {
      slidesPerView: 3,
      spaceBetween: 40,
      slidesPerGroup: 2,
      loop: true,
      centerSlide: "true",
      grabCursor: "true",
      fade: "true",
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
        dinamicBullets: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });

$(document).ready(function(){

          $('.sub-btn').click(function(){
            $(this).next('.sub-menu').slideToggle();
            $(this).find('.dropdown').toggleClass('rotate');
          });

          $('.menu-btn').click(function(){
            $('.side-bar').addClass('active');
            $('.menu-btn').css("visibility", "hidden");
          });

          $('.close-btn').click(function(){
            $('.side-bar').removeClass('active');
            $('.menu-btn').css("visibility", "visible");
          });

        });